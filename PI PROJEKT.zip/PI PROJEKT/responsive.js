function changeColor() {
    var w = window.outerWidth;
    var h = window.outerHeight;
    if(h>1280 || w>1024)
        document.getElementById("page-wrapper").style.backgroundColor = "blue";
    else
        document.getElementById("page-wrapper").style.backgroundColor = "red";
}